document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('.form');
  
    form.addEventListener('submit', e => {
      e.preventDefault();
      let valid = true;
  
      if (!document.getElementById('war').checked) {
        alert('Musisz zaakceptować warunki beta testów.');
        valid = false;
      }
      if (!document.getElementById('dan').checked) {
        alert('Musisz wyrazić zgodę na przetwarzanie danych.');
        valid = false;
      }
  
      if (!valid) return;
      alert('Dziękujemy! Twój formularz został pomyślnie wysłany.');
      window.location.href = 'index.html';
    });
  });
  