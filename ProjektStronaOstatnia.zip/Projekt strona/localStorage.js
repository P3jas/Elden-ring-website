function getFormControls() {
    return Array.from(document.querySelectorAll(
      'input[type=text], input[type=email], input[type=tel], input[type=radio], input[type=checkbox], select, textarea'
    ));
  }
  
  function saveFormData() {
    getFormControls().forEach(control => {
      const key = 'form_' + (control.id || control.name || control.placeholder || control.type + '_' + control.value);
      if (control.type === 'checkbox' || control.type === 'radio') {
        localStorage.setItem(key, control.checked);
      } else {
        localStorage.setItem(key, control.value);
      }
    });
  }
  
  function loadFormData() {
    getFormControls().forEach(control => {
      const key = 'form_' + (control.id || control.name || control.placeholder || control.type + '_' + control.value);
      const stored = localStorage.getItem(key);
      if (stored === null) return;
      if (control.type === 'checkbox' || control.type === 'radio') {
        control.checked = (stored === 'true');
      } else {
        control.value = stored;
      }
    });
  }
  
  function clearFormData() {
    getFormControls().forEach(control => {
      const key = 'form_' + (control.id || control.name || control.placeholder || control.type + '_' + control.value);
      localStorage.removeItem(key);
    });
  }
  
  window.addEventListener('DOMContentLoaded', () => {
    loadFormData();
    getFormControls().forEach(control => {
      control.addEventListener('input', saveFormData);
      control.addEventListener('change', saveFormData);
    });
    const form = document.querySelector('form');
    if (form) {
      form.addEventListener('submit', () => {
        clearFormData();
      });
    }
  });
  