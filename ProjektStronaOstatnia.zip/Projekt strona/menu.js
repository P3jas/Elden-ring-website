const toggleBtn = document.querySelector('.navToggle img')
const navList = document.querySelector('.navList')

toggleBtn.onclick = function () {
    navList.classList.toggle('open')
} 