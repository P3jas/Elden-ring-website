const days = document.getElementById("days");
const hours = document.getElementById("hours");
const minutes = document.getElementById("minutes");
const secounds = document.getElementById("secounds");

const releseDate = new Date("May 30 2025 00:00:00");

function updateTimer() {
    const currentTime = new Date();
    const diff = releseDate - currentTime;
    
    const d = Math.floor(diff / 1000 / 60 / 60 / 24);
    const h = Math.floor(diff / 1000 / 60 / 60 ) % 24;
    const m = Math.floor(diff / 1000 / 60 ) % 60;
    const s = Math.floor(diff / 1000) % 60;


    days.innerHTML = d;
    hours.innerHTML = h;
    minutes.innerHTML = m;
    secounds.innerHTML = s;
}

setInterval(updateTimer,1000);